﻿using System;
using Verse;
using Verse.Sound;
using RimWorld;
using UnityEngine;

namespace WeaponsOfElysion
{
    public class ExplodingBullet : Projectile
    {

        protected override void Impact(Thing hitThing)
        {
            Map map = base.Map;
            base.Impact(hitThing);
            if (hitThing != null)
            {
                GenExplosion.DoExplosion(hitThing.Position, map, 0.2f, DamageDefOf.Bomb, null, null, null, null, null, 0f, 1, false, null, 0f, 1);
                int damageAmountBase = this.def.projectile.damageAmountBase;
                ThingDef equipmentDef = this.equipmentDef;
                DamageInfo dinfo = new DamageInfo(this.def.projectile.damageDef, damageAmountBase, this.ExactRotation.eulerAngles.y, this.launcher, null, equipmentDef);
                hitThing.TakeDamage(dinfo);
            }
            else
            {
                GenExplosion.DoExplosion(this.Position, map, 0.2f, DamageDefOf.Bomb, null, null, null, null, null, 0f, 1, false, null, 0f, 1);
                SoundDefOf.BulletImpactGround.PlayOneShot(new TargetInfo(base.Position, map, false));
                MoteMaker.MakeStaticMote(this.ExactPosition, map, ThingDefOf.Mote_ShotHit_Dirt, 1f);
            }
        }
    }
}
