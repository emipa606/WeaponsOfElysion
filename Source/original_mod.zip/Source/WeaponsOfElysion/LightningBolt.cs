﻿using System;
using RimWorld;
using Verse;
using UnityEngine;

namespace WeaponsOfElysion
{
    public class LightningBolt : Thing
    {
        private IntVec3 hitThing;
        private Vector3 origin;
        private Mesh boltMesh;
        private Quaternion direction;
        static readonly Material LightningMat = MatLoader.LoadMat("Weather/LightningBolt");

        public LightningBolt(IntVec3 hitThing, Vector3 origin)
        {
            this.hitThing = hitThing;
            this.origin = origin;
        }

        public void CreateLightningBolt()
        {
            Vector3 hitPosition;
            hitPosition.x = hitThing.x;
            hitPosition.y = hitThing.y;
            hitPosition.z = hitThing.z;
            this.direction = Quaternion.LookRotation((hitPosition - origin).normalized);
            float distance = Vector3.Distance(origin, hitPosition);
            this.boltMesh = ModLightningBoltMeshMaker.NewBoltMesh(distance);
            
            Graphics.DrawMesh(
                this.boltMesh,
                origin,
                this.direction,
                LightningMat,
                0);
        }
        
    }
}
